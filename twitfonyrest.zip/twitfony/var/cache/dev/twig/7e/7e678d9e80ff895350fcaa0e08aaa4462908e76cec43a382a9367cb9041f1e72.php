<?php

/* demo.html.twig */
class __TwigTemplate_4a75437abef1e47a752c5faac20d2e021d8d0593fa7e8f9a1d0f370ba80ea081 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "demo.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'principal' => array($this, 'block_principal'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "demo.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo "Demo";
        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_principal($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "principal"));

        // line 4
        echo "    <div class=\"singleTweet\">
        <div class=\"cabecera\">
            <a href=\"#\">
                <img class=\"avatarBig\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/avatars/BillGates-big.jpg"), "html", null, true);
        echo "\" />
                <strong>Bill Gates</strong>
                <span>@BillGates</span>
            </a>
            <small class=\"time\">18/11/2019 15:22:30</small>
        </div>
        <div class=\"mensaje\">The future is bright for the world’s poorest farmers because of innovative companies like myAgroFarms.</div>
        <div class=\"likes\">❤ 25</div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "demo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 7,  58 => 4,  52 => 3,  39 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}
{% block titulo %}Demo{{ parent() }}{% endblock %}
{% block principal %}
    <div class=\"singleTweet\">
        <div class=\"cabecera\">
            <a href=\"#\">
                <img class=\"avatarBig\" src=\"{{ asset('images/avatars/BillGates-big.jpg') }}\" />
                <strong>Bill Gates</strong>
                <span>@BillGates</span>
            </a>
            <small class=\"time\">18/11/2019 15:22:30</small>
        </div>
        <div class=\"mensaje\">The future is bright for the world’s poorest farmers because of innovative companies like myAgroFarms.</div>
        <div class=\"likes\">❤ 25</div>
    </div>
{% endblock %}", "demo.html.twig", "/home/alfonso/twitfony/templates/demo.html.twig");
    }
}
