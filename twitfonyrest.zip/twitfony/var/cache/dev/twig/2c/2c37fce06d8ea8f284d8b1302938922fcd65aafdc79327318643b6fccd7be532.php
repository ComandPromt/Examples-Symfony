<?php

/* tweet.html.twig */
class __TwigTemplate_4b08b44f3e7fc1aaebe7609cfaebfa456c7a2beae8bae54f989e0f4971bf4629 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "tweet.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'principal' => array($this, 'block_principal'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "tweet.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 2, $this->source); })()), "nombreAutor", array()), "html", null, true);
        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_principal($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "principal"));

        // line 4
        echo "    <div class=\"singleTweet\">
        <div class=\"cabecera\">
            <a href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tweet", array("id" => twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 6, $this->source); })()), "id", array()))), "html", null, true);
        echo "\">
                <img class=\"avatarBig\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((("images/avatars/" . twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 7, $this->source); })()), "usuarioAutor", array())) . "-big.jpg")), "html", null, true);
        echo "\" />
                <strong>";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 8, $this->source); })()), "nombreAutor", array()), "html", null, true);
        echo "</strong>
                <span>@";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 9, $this->source); })()), "usuarioAutor", array()), "html", null, true);
        echo "</span>
            </a>
            <small class=\"time\">";
        // line 11
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 11, $this->source); })()), "fecha", array()), "d/m/Y h:i:s"), "html", null, true);
        echo "</small>
        </div>
        <div class=\"mensaje\">";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 13, $this->source); })()), "texto", array()), "html", null, true);
        echo "</div>
        <div class=\"likes\">❤ ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["tweet"]) || array_key_exists("tweet", $context) ? $context["tweet"] : (function () { throw new Twig_Error_Runtime('Variable "tweet" does not exist.', 14, $this->source); })()), "likes", array()), "html", null, true);
        echo "</div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "tweet.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 14,  84 => 13,  79 => 11,  74 => 9,  70 => 8,  66 => 7,  62 => 6,  58 => 4,  52 => 3,  39 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}
{% block titulo %}{{ tweet.nombreAutor }}{{ parent() }}{% endblock %}
{% block principal %}
    <div class=\"singleTweet\">
        <div class=\"cabecera\">
            <a href=\"{{ path('tweet', {'id': tweet.id}) }}\">
                <img class=\"avatarBig\" src=\"{{ asset('images/avatars/' ~ tweet.usuarioAutor ~ '-big.jpg') }}\" />
                <strong>{{ tweet.nombreAutor }}</strong>
                <span>@{{ tweet.usuarioAutor }}</span>
            </a>
            <small class=\"time\">{{ tweet.fecha|date(\"d/m/Y h:i:s\") }}</small>
        </div>
        <div class=\"mensaje\">{{ tweet.texto }}</div>
        <div class=\"likes\">❤ {{ tweet.likes }}</div>
    </div>
{% endblock %}", "tweet.html.twig", "/home/alfonso/twitfony/templates/tweet.html.twig");
    }
}
