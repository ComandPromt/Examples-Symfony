<?php

/* index.html.twig */
class __TwigTemplate_fbdb6c82358fe0c68a9c29b4f2229071b6bc2b9afe6659f1ae0d3b9cd65cde2a extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "index.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'principal' => array($this, 'block_principal'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo "Demo";
        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_principal($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "principal"));

        // line 4
        echo "    <ul class=\"tweetline\">
        <!-- tweet 1 -->
        ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tweets"]) || array_key_exists("tweets", $context) ? $context["tweets"] : (function () { throw new Twig_Error_Runtime('Variable "tweets" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["tweet"]) {
            // line 7
            echo "        <li class=\"tweet\">
            <div class=\"contenido\">
                <div class=\"cabecera\">
                    <a href=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tweet", array("id" => twig_get_attribute($this->env, $this->source, $context["tweet"], "id", array()))), "html", null, true);
            echo "\">
                        <img class=\"avatarSmall\" src=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((("images/avatars/" . twig_get_attribute($this->env, $this->source, $context["tweet"], "usuarioAutor", array())) . "-small.jpg")), "html", null, true);
            echo "\" />
                        <strong>";
            // line 12
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tweet"], "nombreAutor", array()), "html", null, true);
            echo "</strong>
                        <span>@";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tweet"], "usuarioAutor", array()), "html", null, true);
            echo "</span>
                    </a>
                    <small class=\"time\">";
            // line 15
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tweet"], "fecha", array()), "d/m/Y"), "html", null, true);
            echo "</small>
                </div>
                <div class=\"mensaje\">";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tweet"], "texto", array()), "html", null, true);
            echo "</div>
            </div>
        </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tweet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "    </ul>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 21,  93 => 17,  88 => 15,  83 => 13,  79 => 12,  75 => 11,  71 => 10,  66 => 7,  62 => 6,  58 => 4,  52 => 3,  39 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}
{% block titulo %}Demo{{ parent() }}{% endblock %}
{% block principal %}
    <ul class=\"tweetline\">
        <!-- tweet 1 -->
        {% for tweet in tweets %}
        <li class=\"tweet\">
            <div class=\"contenido\">
                <div class=\"cabecera\">
                    <a href=\"{{ path('tweet', {'id': tweet.id}) }}\">
                        <img class=\"avatarSmall\" src=\"{{ asset('images/avatars/' ~ tweet.usuarioAutor ~ '-small.jpg') }}\" />
                        <strong>{{ tweet.nombreAutor }}</strong>
                        <span>@{{ tweet.usuarioAutor }}</span>
                    </a>
                    <small class=\"time\">{{ tweet.fecha|date(\"d/m/Y\") }}</small>
                </div>
                <div class=\"mensaje\">{{ tweet.texto }}</div>
            </div>
        </li>
        {% endfor %}
    </ul>
{% endblock %}", "index.html.twig", "/home/alfonso/twitfony/templates/index.html.twig");
    }
}
