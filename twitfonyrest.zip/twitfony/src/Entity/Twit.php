<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TwitRepository")
 */
class Twit
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nombreAutor;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $usuarioAutor;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $texto;

    /**
     * @ORM\Column(type="datetime")
     */
    private $fecha;

    /**
     * @ORM\Column(type="integer")
     */
    private $likes;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombreAutor(): ?string
    {
        return $this->nombreAutor;
    }

    public function setNombreAutor(string $nombreAutor): self
    {
        $this->nombreAutor = $nombreAutor;

        return $this;
    }

    public function getUsuarioAutor(): ?string
    {
        return $this->usuarioAutor;
    }

    public function setUsuarioAutor(string $usuarioAutor): self
    {
        $this->usuarioAutor = $usuarioAutor;

        return $this;
    }

    public function getTexto(): ?string
    {
        return $this->texto;
    }

    public function setTexto(string $texto): self
    {
        $this->texto = $texto;

        return $this;
    }

    public function getFecha(): ?\DateTimeInterface
    {
        return $this->fecha;
    }

    public function setFecha(\DateTimeInterface $fecha): self
    {
        $this->fecha = $fecha;

        return $this;
    }

    public function getLikes(): ?int
    {
        return $this->likes;
    }

    public function setLikes(int $likes): self
    {
        $this->likes = $likes;

        return $this;
    }
}
