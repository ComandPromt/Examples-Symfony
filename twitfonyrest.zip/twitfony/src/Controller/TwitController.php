<?php


namespace App\Controller;

use App\Entity\Twit;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class TwitController extends AbstractController
{
    function index() {
        $entityManager = $this->getDoctrine()->getManager();
        $tweets = $entityManager->getRepository(Twit::class)->findAll();
        return $this->render('index.html.twig', array('tweets' => $tweets));
    }

    function showTweet($id) {
        $entityManager = $this->getDoctrine()->getManager();
        $tweet = $entityManager->getRepository(Twit::class)->find($id);
        return $this->render('tweet.html.twig',array('tweet'=>$tweet));
    }
}