<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Twit;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);
        $twit = new Twit();
        $twit->setNombreAutor("Bill Gates");
        $twit->setUsuarioAutor("BillGates");
        $twit->setFecha(new \DateTime("19-11-2018 09:08:03"));
        $twit->setLikes(20);
        $twit->setTexto("The future is bright for the world’s poorest farmers because of innovative companies like myAgroFarms.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Sundar Pichai");
        $twit->setUsuarioAutor("sundarpichai");
        $twit->setFecha(new \DateTime("19-11-2018 07:51:32"));
        $twit->setLikes(52);
        $twit->setTexto("DeepMind will continue to lead the way in fundamental research applying AI to important science and medical research questions, in collaboration w/partners, to accelerate scientific progress for the benefit of everyone.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Linus Torvalds");
        $twit->setUsuarioAutor("Linus__Torvalds");
        $twit->setFecha(new \DateTime("18-11-2018 19:28:12"));
        $twit->setLikes(27);
        $twit->setTexto("Linux Nears Total Domination of the Top500 Supercomputers.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Tim Cook");
        $twit->setUsuarioAutor("tim_cook");
        $twit->setFecha(new \DateTime("18-11-2018 10:15:25"));
        $twit->setLikes(25);
        $twit->setTexto("C’est magnifique ! Apple Champs-Élysées is open for all to enjoy. Thank you to everyone who worked on the restoration of this historic building — it’s stunning. Venez le découvrir par vous-même !");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Bill Gates");
        $twit->setUsuarioAutor("BillGates");
        $twit->setFecha(new \DateTime("17-11-2018 19:08:05"));
        $twit->setLikes(03);
        $twit->setTexto("Whenever I travel for the foundation, the farmers I meet talk about one thing that holds them back: they can’t save their money. @myAgroFarms is one of the companies working on creative solutions to this problem.");
        $manager->persist($twit);

        $twit = new Twit();
        $twit->setNombreAutor("Tim Cook");
        $twit->setUsuarioAutor("tim_cook");
        $twit->setFecha(new \DateTime("17-11-2018 11:15:35"));
        $twit->setLikes(12);
        $twit->setTexto("Proud of this team and the work they do to leave our world better than we found it. Congratulations and thank you!");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Sundar Pichai");
        $twit->setUsuarioAutor("sundarpichai");
        $twit->setFecha(new \DateTime("15-11-2018 09:23:11"));
        $twit->setLikes(23);
        $twit->setTexto("We are mobilizing to support those impacted by the #CampFire, #HillFire and #WoolseyFire with SOS Alerts, and committing resources from @googleorg to aid those in need. Our thoughts are with all those displaced by these fires.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Bill Gates");
        $twit->setUsuarioAutor("BillGates");
        $twit->setFecha(new \DateTime("15-11-2018 08:12:36"));
        $twit->setLikes(13);
        $twit->setTexto("Farm yields in many parts of Africa are just a fifth of those in the United States. Innovations in agriculture will make it possible for poor farmers to increase their yields.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Sundar Pichai");
        $twit->setUsuarioAutor("sundarpichai");
        $twit->setFecha(new \DateTime("12-11-2018 12:11:32"));
        $twit->setLikes(81);
        $twit->setTexto("We’re announcing our AI for Social Good program, applying @GoogleAI expertise to projects w/ positive societal impact. We invite researchers & orgs to submit ideas for the #GoogleAI Impact Challenge: @googleorg will fund $25M in grants to chosen projects.");
        $manager->persist($twit);

        $twit = new Twit();
        $twit->setNombreAutor("Tim Cook");
        $twit->setUsuarioAutor("tim_cook");
        $twit->setFecha(new \DateTime("11-11-2018 11:15:25"));
        $twit->setLikes(73);
        $twit->setTexto("We have so much to learn from those who sacrifice for the common good. To the women and men of our military — both past and present, including my father— we are forever grateful for your service.");
        $manager->persist($twit);


        $twit = new Twit();
        $twit->setNombreAutor("Linus Torvalds");
        $twit->setUsuarioAutor("Linus__Torvalds");
        $twit->setFecha(new \DateTime("10-11-2018 10:31:12"));
        $twit->setLikes(53);
        $twit->setTexto("Linux Foundation Training Prepares the International Space Station for Linux Migration.");
        $manager->persist($twit);

        $twit = new Twit();
        $twit->setNombreAutor("Linus Torvalds");
        $twit->setUsuarioAutor("Linus__Torvalds");
        $twit->setFecha(new \DateTime("08-11-2018 01:15:25"));
        $twit->setLikes(14);
        $twit->setTexto("Free Intro to Linux Online Course Starts Today.");
        $manager->persist($twit);

        $manager->flush();
    }
}
